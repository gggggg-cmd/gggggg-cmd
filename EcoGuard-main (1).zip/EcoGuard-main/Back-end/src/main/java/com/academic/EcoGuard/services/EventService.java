package com.academic.EcoGuard.services;

import com.academic.EcoGuard.dtos.EventDto;

public interface EventService {

    public EventDto join(String evenId,String userId);

}
