package com.academic.EcoGuard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcoGuardApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcoGuardApplication.class, args);
	}

}
