package com.academic.EcoGuard.Config;

public class AsyncConfig {
}
