package com.academic.EcoGuard.repositories;

import com.academic.EcoGuard.entities.CToken;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CTokenRepo extends JpaRepository<CToken,String> {

}
