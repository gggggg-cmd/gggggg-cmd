
'use client'; 
import SocialPage from '@/components/app-social-page'
import Layout from '@/components/Layout'
import React from 'react'
import dynamic from 'next/dynamic'


function Community() {
  return (
   <Layout><SocialPage/></Layout>



   
  )
}

export default Community
