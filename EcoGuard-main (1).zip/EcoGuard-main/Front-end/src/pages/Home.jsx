'use client';

import HomePage from '@/components/Home-page'
import Layout from '@/components/Layout'
import React from 'react'

function Main() {
  return (
 
    <Layout>


<HomePage/>
      
    </Layout>
    
       
  
  )
}

export default Main
