'use client'; 

import ProfilePage from '@/components/app-profile-page'
import Layout from '@/components/Layout'
import React from 'react'



function Profile() {
  return (
    <Layout>
   
    <ProfilePage/>
    </Layout>
   
  )
}

export default Profile
