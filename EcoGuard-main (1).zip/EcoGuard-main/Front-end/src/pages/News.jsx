'use client'; 

import NewsPage from '@/components/app-news-page';

import React from 'react'
import Layout from '@/components/Layout';

function News() {
  return (
    <Layout>
<NewsPage/>
</Layout>


   
  )
}

export default News
