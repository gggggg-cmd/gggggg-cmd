import JoinEventForm from '@/components/app-join-event-page'
import  Layout  from '@/components/Layout'
import React from 'react'

function Event() {
  return (
  
    <Layout>



<JoinEventForm/>
</Layout>

   
   
  )}
export default Event
