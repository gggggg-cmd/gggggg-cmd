'use client'; 


import { DeforestationDetectionLandingJsx } from '@/components/deforestation-detection-landing'
import Layout from '@/components/Layout'
import React from 'react'

function Deforestation() {
  return (
    <Layout><DeforestationDetectionLandingJsx/></Layout>



    
  )
}

export default Deforestation
